# LaTeX template for school assignments
